while wait(2) do
game.Workspace.TouchTrigger.Donut.Position = game:GetService("Players").LocalPlayer.Character.Head.Position
end